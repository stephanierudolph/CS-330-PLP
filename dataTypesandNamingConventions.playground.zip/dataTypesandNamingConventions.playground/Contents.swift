import UIKit

var name = "hello" //implicitly
var lastName: String = "Green" //explicitly

var num = 5
var _num2 = 10.4

var variable: Int = 10
var anotherNum: Float = 10.77
var double: Double = 9.127283782

var eval = true
var check: Bool = false

var Array: Array<String> = ["apple", "orange", "banana"]
var aList: [Int] = [0, 8, 900]
var _grades = [90, 88, 60, 74]
var anotherArray: Array<Any> = ["red", 20.5, true, 5] //to have mixed types in an Array, it msut be explictly decalred
print(anotherArray)

//num = num + "five" <- does not work because Swift is strongly typed
/*
 var test = 5
 test = "hello" <- does not work because Swift is immutable
 */

var num1 = 5
var num2 = 10.6
//var num3 = num1 + num2 does not work
var num3 = Double(num1) + num2

