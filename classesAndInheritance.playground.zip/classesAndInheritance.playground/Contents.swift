import UIKit

class Person{
    var name = ""
    var age = 0
    var job = ""
    
    func about() -> String{
        var personDetails = (name + ", " + String(age) + ", " + job)
        return(personDetails)
    }
    func canDrink() -> Bool{
            if age >= 21{
                return(true)
            }else{
                return(false)
            }
        }
    }


var myPerson = Person()
print(myPerson.age)
myPerson.age = 20
print(myPerson.age)
myPerson.name = "Sam"
myPerson.job = "Circus Clown"
print(myPerson.about())
print(myPerson.canDrink())

class Student: Person{
    var gradYear = 2027
    var tuitionPaid = true
    
    override func about() -> String{
        var personDetails = (name + ", " + String(age) + ", " + job + ", " + String(gradYear) + ", " + String(tuitionPaid))
            return(personDetails)
    }
    func tuitionNotice() -> String{
        
        if tuitionPaid{
            return("Tuition has been paid")
        }else{
            return("Please pay tuition.")
        }
    }
}

var myStudent = Student()
myStudent.age = 18
myStudent.job = "Student"
myStudent.name = "Bella"
myStudent.tuitionPaid = false
print(myStudent.canDrink())
print(myStudent.about())
print(myStudent.tuitionNotice())

struct MyStruct{
    var myInt = 10
}

var structOne = MyStruct()
structOne.myInt = 90
print(structOne.myInt)
