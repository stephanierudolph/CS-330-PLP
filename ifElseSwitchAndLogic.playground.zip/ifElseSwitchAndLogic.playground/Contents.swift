import UIKit
//If-else, Switch, and Logical Operators

var a = 1
var b = 2
var c = 3

if a > b{
    print("A is larger than B")
}else{
    print("B is larger than A")
}


if a > b || c > b{
    print("a or c is larger than b")
}
if a > b{
    print("a > b")//false
}else if b > c{
    print("b > c")//false
}else{//executes this line
    print("a < b and b < c")
}
//guard statement
var temp = 5
func testGuard(temp: Int) -> Void{
    
    guard temp == 5 else{
        print("temp is not 5")
        return
    }
    
    print("temp is 5")
    
}
testGuard(temp: 5)
//short circuiting

if a > b && b < a{
    print("yes")
}else{
    print("no")
}

switch c{
case 1:
    print("1")
case 2:
    print("2")
case 3:
    print("3")
default:
    break
}


for r in 0...10{
    switch r{
    case 1: continue
    case 2: continue
    case 4: print("4")
    case 5: break
    case 6: print("5")
    default: continue
    }
}
