import UIKit

var fruit = ["apple", "banana", "kiwi", "grape"]

//for-in loop
for f in fruit{
    print(f)
}
//while
 var vegtable = 0
 while vegtable < 10{
 vegtable += 1
 print(vegtable)
 }
 
//repeat-while
var grain = 0
repeat{
    grain += 1
    print(grain)
}while grain < 5

//for-in and while
for f in fruit where f != "kiwi"{
    print(f)
}

//multiplication function
func multiply(a: Int, b:Int) -> Int{
    a*b
}
print(multiply(a:2, b:5))

//function that takes 2 parameters of differing types
func myFunc2( a: Int, b: Double) -> String{
    if Double(a) > b{
        return("nice")
    } else{
        return("also nice")
    }
}
//returning tuples
func myFunc3() -> (width: Int, height: Int){
    return(width: 5, height: 20)
}
print(myFunc3())

//recursion
func factorial(number: Int) -> Int{
    if number == 0{
        return 1
    }
    else{
        return number * factorial(number: number - 1)
    }
}

print(factorial(number: 5))

//splits string function
func splitWord(words: String) -> Array<Substring>{
    return(words.split(separator: " ")) //strings can use the .split() method
}
var helloWorldSplit = splitWord(words: "Hello world")
print(helloWorldSplit)

var a = 5

//pass by refrence
func passByRef(_ array: inout [Int]) {
    array.append(4)
}
var nums = [0, 1, 2, 3]
print(nums)
passByRef(&nums)
print(nums)

var testVal = 5
func myFunc4() -> Bool{
    var anotherTestValue = 2
    var new = testVal + anotherTestValue
    if new > 2{
        return(true)
    }
    return(false)
}

print(myFunc4())
